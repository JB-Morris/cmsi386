#use "hw3.ml";;

mocaml();;
