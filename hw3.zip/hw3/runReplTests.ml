#use "hw3.ml";;

runReplTests();;

